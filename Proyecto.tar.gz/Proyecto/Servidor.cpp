#include <iostream>
#include <sys/socket.h>
#include "Cliente.cpp"
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <stdio.h> 

using namespace std;

class Servidor{
	private:
		int Puerto;
		int Socket;
		struct sockaddr_in Direccion_Servidor;
	public:
		Servidor(int Puerto){
			this->Puerto = Puerto;
		}
		
		//Metodos
		//LEVANTAR SERVICIO
		void Crear_Socket(){
			//AF_INET = IPv4 
			//SOCK_STREAM = TCP
			//0 = Valor protocolo TCP
			if((this->Socket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
				cout << "ERROR\n";
				exit(EXIT_FAILURE);
			}
		}
		
		//Enlazar el socket al puerto
		void Configurar_Estructura(){
			//Limpiemos la memoria
			memset(&this->Direccion_Servidor,0,sizeof(this->Direccion_Servidor));
			//Configuramos la estructura
			Direccion_Servidor.sin_family = AF_INET;//IPv4
			Direccion_Servidor.sin_addr.s_addr = htonl(INADDR_ANY);//Asignamos IP por defecto 0.0.0.0
			Direccion_Servidor.sin_port = htons(Puerto);//Asignamos puerto ingresado por usuario
		}
		
		//BIND_SOCKET
		void Unir_Socket_Estructura(){
			if ( bind(this->Socket, (struct sockaddr *) &this->Direccion_Servidor, sizeof(this->Direccion_Servidor)) < 0 ) {
				cout << "ERROR\n";
				exit(EXIT_FAILURE);
			  }
		}
		
		//CONECTAR AL SERVICIO
		//Se verifica numero maximo de conexiones
		void Limitar_Conexiones(){
			if(listen(this->Socket,1024) < 0){
				cout << "ERROR\n";
				exit(EXIT_FAILURE);
			}
		}
};






