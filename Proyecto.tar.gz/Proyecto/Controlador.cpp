#include <iostream>
//Se incluyen los programas del servidor y el cliente 
#include "Servidor.cpp"
#include "Cliente.cpp"

using namespace std;

int main(int argc, char *argv[]){
	int Puerto;//Variable que almacena el puerto ingresado por el usuario
	//Funcion atoi transforma el char en la posicion 1 que contiene el puerto en una variable int
	Puerto = atoi(argv[1]);
	
	//Se validan los parametros ingresados por el usuario, en caso que no ingrese un puerto a conectarse
	if(argc != 2 || Puerto <= 1024){
		cout << "Comando mal ingresado. Ingrese un puerto a conectarse sobre 1024\n";
		exit(-1);
	}
	
	//Instanciamos el servidor, al cual le traspasamos el puerto ingresado
	Servidor *Server = new Servidor(Puerto);
	
	
	return 0;
}
