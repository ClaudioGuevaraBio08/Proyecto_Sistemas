#include <iostream>
#include <fstream>
#include <unistd.h>

#include "Servidor.cpp"

using namespace std;

int main(int argc, char *argv[]){
	int Puerto = 0;
	
	if(argc != 2){
		cout << "Error. Debe ingresar un puerto\n";
		exit(-1);
	}
	
	Puerto = atoi(argv[1]);
	
	Servidor *server = new Servidor(Puerto);
	server->Programa();
	
	return 0;
}
