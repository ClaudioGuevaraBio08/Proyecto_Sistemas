#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <thread>

using namespace std;

class Servidor{
	private:
		int Puerto = 0;
		int Socket_Servidor = 0;
		int Nuevo_Socket_Servidor = 0;
		struct sockaddr_in Estructura_Servidor;
		struct sockaddr_in Estructura_Cliente_Conectado;
		socklen_t Cliente_Conectado = sizeof(Estructura_Cliente_Conectado);
	public: 
		Servidor(int Puerto){
			this->Puerto = Puerto;
		}
		
		//METODOS
		void Crear_Socket(){
			if((Socket_Servidor = socket(AF_INET, SOCK_STREAM, 0)) < 0){
				cout << "Error de creación del socket";
				exit(EXIT_FAILURE);
			}
		}
		
		void Configurar_Estructura(){
			memset(&Estructura_Servidor, '0', sizeof(Estructura_Servidor));
			
			Estructura_Servidor.sin_family = AF_INET;
			Estructura_Servidor.sin_addr.s_addr = htonl(INADDR_ANY);
			Estructura_Servidor.sin_port = htons(this->Puerto);
			
		}	
		
		void Union(){
			if(bind(Socket_Servidor, (struct sockaddr*)&Estructura_Servidor, sizeof(Estructura_Servidor)) < 0){
				cout << "ERROR";
				exit(EXIT_FAILURE);
			}
		}
		
		void Escuchando(){
			if(listen(Socket_Servidor,1024) < 0){
				cout << "ERROR";
				exit(EXIT_FAILURE);
			}
		}
		
		void Esperando_Conexiones(){
			
			while(true){
				while((Nuevo_Socket_Servidor = accept(Socket_Servidor, (struct sockaddr *) &Estructura_Cliente_Conectado, &Cliente_Conectado)) > 0){
					thread Hebra(Juego,Nuevo_Socket_Servidor);
					Hebra.detach();
				}
			}
		}
		
		static void Juego(int Nuevo_Socket_Servidor){
			char MESSAGE[200];
			
			recv(Nuevo_Socket_Servidor,MESSAGE, sizeof(MESSAGE),0);
					
			string msg;
			msg = MESSAGE;
			cout << "el cliente dice:\t" << msg << endl;
			
			string reply;
			cout << "Respuesta del servidor:\t";
			getline(cin,reply);
			
			const char* s = reply.c_str();
			send(Nuevo_Socket_Servidor,s,1024,0);
			
		}
			
		void Programa(){
			Crear_Socket();
			Configurar_Estructura();
			Union();
			Escuchando();
			Esperando_Conexiones();
		}
		
};
 

