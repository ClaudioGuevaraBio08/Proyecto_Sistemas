#include <iostream>
#include <fstream>
#include <unistd.h>

#include "Cliente.cpp"

using namespace std;

int main(int argc, char *argv[]){
	int Puerto;
	int Direccion_IP;	
	if(argc != 3){
		cout << "Error. Debe ingresar una direccion IP y un puerto\n";
		exit(-1);
	}
	Direccion_IP = argv[1];
	Puerto = atoi(argv[2]);
	
	Cliente *cliente = new Cliente(Direccion_IP, Puerto);
	cliente->Programa();
	
	return 0;
}
