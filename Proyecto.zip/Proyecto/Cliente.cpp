#include <iostream>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>

using namespace std;


class Cliente{
	private:
		char *Direccion_IP;
		int Socket_Cliente = 0;
		int Puerto = 0;
		int n=0;
		char recvBuff[1024];
		struct sockaddr_in Estructura_Cliente;
	public:
		Cliente(char* Direccion_IP,int Puerto){
			this->Direccion_IP = Direccion_IP;
			this->Puerto = Puerto;
		}
		
		//METODOS
		
		void Crear_Socket(){
			if((Socket_Cliente = socket(AF_INET, SOCK_STREAM, 0)) < 0){
				cout << "Error de creación del socket";
				exit(EXIT_FAILURE);
			}
		}
		
		void Configurar_Estructura(){
			memset(&Estructura_Cliente, '0', sizeof(Estructura_Cliente));
			memset(recvBuff, '0', sizeof(recvBuff));
		
			Estructura_Cliente.sin_family = AF_INET;
			Estructura_Cliente.sin_port = htons(this->Puerto);
			
			if(inet_pton(AF_INET, Direccion_IP, &Estructura_Cliente.sin_addr) <= 0){
				cout << "ERROR";
				exit(EXIT_FAILURE);
			}
		}
		
		void Conexion(){
			
			char MESSAGE[200];
			if(connect(Socket_Cliente, (struct sockaddr *)&Estructura_Cliente, sizeof(Estructura_Cliente)) < 0){
				cout << "ERROR";
				exit(EXIT_FAILURE);
			}
			string msg;
			cout << "Enviar: \n";
			cin >> msg;
			const char* s = msg.c_str();
			send(Socket_Cliente, s, 1024, 0);
			recv(Socket_Cliente, MESSAGE, sizeof(MESSAGE), 0);
			string reply;
			reply = MESSAGE;
			cout << "Servidor dice: \n" << reply << endl;
		}
		
		void Programa(){
			while(1){
				Crear_Socket();
				Configurar_Estructura();
				Conexion();
			}
		}
		
		
		

};
