#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 4455

int main(){
	int socket_cliente;
	struct sockaddr_in serveraddr;
	char buffer[1024];
	
	socket_cliente = socket(PF_INET,SOCK_STREAM,0);
	printf("[+]Server Socket Created Succssfully\n");
	memset(&serveraddr, '\0', sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(PORT); 
	serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	connect(socket_cliente, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	printf("[+]Connected to the server\n");
	
	recv(socket_cliente,buffer,1024,0);
	printf("[+]Data reciver : %s",buffer);
	
	return 0;
}
